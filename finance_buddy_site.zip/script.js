
const taxData = {
  "USA": { brackets: [[0, 0.10], [10275, 0.12], [41775, 0.22], [89075, 0.24], [170050, 0.32], [215950, 0.35], [539900, 0.37]], taxFree: false },
  "India": { brackets: [[0, 0.05], [250000, 0.10], [500000, 0.20], [1000000, 0.30]], taxFree: false },
  "UK": { brackets: [[0, 0.0], [12570, 0.20], [50270, 0.40], [150000, 0.45]], taxFree: false },
  "Canada": { brackets: [[0, 0.15], [53359, 0.205], [106717, 0.26], [165430, 0.29], [235675, 0.33]], taxFree: false },
  "Australia": { brackets: [[0, 0.0], [18200, 0.19], [45000, 0.325], [120000, 0.37], [180000, 0.45]], taxFree: false },
  "Germany": { brackets: [[0, 0.0], [9744, 0.14], [14753, 0.239], [57918, 0.42], [274612, 0.45]], taxFree: false },
  "Singapore": { brackets: [[0, 0.0], [20000, 0.02], [30000, 0.035], [40000, 0.07], [80000, 0.115], [120000, 0.15], [160000, 0.18], [200000, 0.19], [240000, 0.195], [280000, 0.20], [320000, 0.22]], taxFree: false },
  "UAE": { brackets: [], taxFree: true },
  "Monaco": { brackets: [], taxFree: true },
  "Bahamas": { brackets: [], taxFree: true }
};

function calculateTax() {
  const country = document.getElementById('country').value;
  let income = parseFloat(document.getElementById('income').value) || 0;
  const deductions = parseFloat(document.getElementById('deductions').value) || 0;
  income -= deductions;

  if (taxData[country]?.taxFree) {
    document.getElementById('taxResult').innerText = `Good news! ${country} has no personal income tax.`;
    return;
  }

  let estimatedTax = 0;
  let taxableIncome = income;

  const brackets = taxData[country]?.brackets || [];
  for (let i = brackets.length - 1; i >= 0; i--) {
    if (taxableIncome > brackets[i][0]) {
      estimatedTax += (taxableIncome - brackets[i][0]) * brackets[i][1];
      taxableIncome = brackets[i][0];
    }
  }

  document.getElementById('taxResult').innerText = `Estimated Tax for ${country}: $${estimatedTax.toFixed(2)}`;
}

function calculateGoal() {
  const goalAmount = parseFloat(document.getElementById('goalAmount').value) || 0;
  const months = parseInt(document.getElementById('months').value) || 1;
  const monthlySaving = goalAmount / months;
  document.getElementById('goalResult').innerText = `You need to save $${monthlySaving.toFixed(2)} per month.`;
}

function giveAdvice() {
  const income = parseFloat(document.getElementById('userIncome').value) || 0;
  const expenses = parseFloat(document.getElementById('userExpenses').value) || 0;
  if (income <= expenses) {
    document.getElementById('adviceResult').innerText = "Your expenses are too high! Focus on cutting down costs first.";
  } else {
    const saving = ((income - expenses) / income) * 100;
    document.getElementById('adviceResult').innerText = `You're saving ${saving.toFixed(1)}% of your income. Great job! Aim to save at least 20%.`;
  }
}
